#!/bin/sh

rm -rf {1,2}/testnet3/database.*.bak
rm -rf armory/armory_*_backup.wallet

